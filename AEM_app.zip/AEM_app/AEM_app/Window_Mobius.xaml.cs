﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AEM_app
{
    /// <summary>
    /// Interaction logic for Window_Mobius.xaml
    /// </summary>
   
    public partial class Window_Mobius : Window
    {
        public List<Point> listOfPoints;

        public Window_Mobius()
        {
            InitializeComponent();
            listOfPoints = new List<Point>();
            Button_createFunction.IsEnabled = false;
        }

        public void RunMobius()
        {
            int X = int.Parse(value.Text);

            for (int i = 1; i <= X; i++)
            {
                listOfPoints.Add(new Point(i, FMobius(i)));
            }
        }

        public int FMobius(int n)
        {
            if (n == 1) return 1;
            else if (n == 2) return -1;

            int p = 0;

            if (n % 2 == 0)
            {
                n = n / 2;
                p++;

                if (n % 2 == 0)
                    return 0;
            }

            for (int i = 3; i <= Math.Sqrt(n); i = i + 2)
            {
                if (n % i == 0)
                {
                    n = n / i;
                    p++;

                    if (n % i == 0)
                        return 0;
                }
            }

            return (p % 2 == 0) ? -1 : 1;
        }


        private void Button_createFunction_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                chartM.Series.Clear();
                listOfPoints.Clear();
                RunMobius();

                ScatterSeries series = new ScatterSeries
                {
                    DependentValuePath = "Y",
                    IndependentValuePath = "X",
                    ItemsSource = listOfPoints
                };

                chartM.Series.Add(series);

                Window_Values wv = new Window_Values("Mobius - values", listOfPoints);
                wv.Show();
            }
            catch (Exception)
            {
                MessageBox.Show("ERROR - sprawdź wprowadzone X !");
            }
        }

        private void Value_KeyDown(object sender, KeyEventArgs e)
        {
            Button_createFunction.IsEnabled = true;
        }
    }
}
