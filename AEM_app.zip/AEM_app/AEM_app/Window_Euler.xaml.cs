﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AEM_app
{
    /// <summary>
    /// Interaction logic for Window_Euler.xaml
    /// </summary>

    public partial class Window_Euler : Window
    {
        public List<Point> listOfPoints;

        public Window_Euler()
        {
            InitializeComponent();
            listOfPoints = new List<Point>();
            Button_createFunction.IsEnabled = false;
        }

        public int FEuler(int n)
        {
            if (n == 1)
                return 1;

            bool[] prime = new bool[n + 1];
            bool[] primesquare = new bool[(n * n) + 1];

            int[] a = new int[n];

            FEuler2(n, prime, primesquare, a);

            int ans = 1;

            for (int i = 0; ; i++)
            {

                if (a[i] * a[i] * a[i] > n)
                    break;

                int cnt = 1;

                while (n % a[i] == 0)
                {
                    n = n / a[i];
                    cnt = cnt + 1;
                }
                ans = ans * cnt;
            }

            if (prime[n])
                ans = ans * 2;
            else if (primesquare[n])
                ans = ans * 3;
            else if (n != 1)
                ans = ans * 4;

            return ans;
        }

        public void FEuler2(int n, bool[] prime, bool[] primesquare, int[] a)
        {
            for (int i = 2; i <= n; i++)
                prime[i] = true;

            for (int i = 0; i < ((n * n) + 1); i++)
                primesquare[i] = false;

            prime[1] = false;

            for (int p = 2; p * p <= n; p++)
            {
                if (prime[p] == true)
                {
                    for (int i = p * 2; i <= n; i += p)
                        prime[i] = false;
                }
            }

            int j = 0;
            for (int p = 2; p <= n; p++)
            {
                if (prime[p])
                {
                    a[j] = p;

                    primesquare[p * p] = true;
                    j++;
                }
            }

        }

        public void RunEuler()
        {
            int X = int.Parse(value.Text);

            for (int i = 1; i <= X; i++)
            {
                listOfPoints.Add(new Point(i, FEuler(i)));
            }
        }


        private void Button_createFunction_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                chartE.Series.Clear();
                listOfPoints.Clear();
                RunEuler();

                LineSeries series = new LineSeries
                {
                    DependentValuePath = "Y",
                    IndependentValuePath = "X",
                    ItemsSource = listOfPoints
                };

                chart_X.Maximum = listOfPoints.Max(point => point.Y) + 1;
                chart_X.Minimum = 0;

                chartE.Series.Add(series);

                Window_Values wv = new Window_Values("Euler - values", listOfPoints);
                wv.Show();

            }
            catch (Exception)
            {
                MessageBox.Show("ERROR - sprawdź wprowadzone P!");
            }

        }
        private void Value_KeyDown(object sender, KeyEventArgs e)
        {
            Button_createFunction.IsEnabled = true;
        }
    }
}