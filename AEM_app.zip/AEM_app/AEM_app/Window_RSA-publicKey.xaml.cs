﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AEM_app
{
    /// <summary>
    /// Interaction logic for Window_RSA_publicKey.xaml
    /// </summary>
    
    public partial class Window_RSA_publicKey : Window
    {
        private RSACryptoServiceProvider csp;
        private byte[] encryptedText;
        public String KEY;

        public Window_RSA_publicKey()
        {
            InitializeComponent();

            csp = new RSACryptoServiceProvider(2048);
            RSAParameters pubKey = csp.ExportParameters(false);
            var sw = new StringWriter();
            var xs = new System.Xml.Serialization.XmlSerializer(typeof(RSAParameters));
            xs.Serialize(sw, pubKey);
            KEY = sw.ToString();

            Button_Code.IsEnabled = false;
        }

        private void Button_Key_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(KEY);
        }

        private void Button_Code_Click(object sender, RoutedEventArgs e)
        {
            Encrypt();
            Decrypt();
        }

        private void Encrypt()
        {
            var sr = new StringReader(KEY);
            var xs = new System.Xml.Serialization.XmlSerializer(typeof(RSAParameters));

            RSACryptoServiceProvider csp = new RSACryptoServiceProvider();
            csp.ImportParameters((RSAParameters)xs.Deserialize(sr));
            byte[] bytesPlainTextData = System.Text.Encoding.Unicode.GetBytes(TB_Text.Text);
            this.encryptedText = csp.Encrypt(bytesPlainTextData, false);
            string encryptedText = Convert.ToBase64String(this.encryptedText);
            TB_Encrypted.Text = encryptedText;
        }

        private void Decrypt()
        {
            byte[] decrypted = csp.Decrypt(encryptedText, false);
            TB_Decrypted.Text = System.Text.Encoding.Unicode.GetString(decrypted);
        }

        private void TB_Text_KeyDown(object sender, KeyEventArgs e)
        {
            Button_Code.IsEnabled = true;
        }
    }
}
