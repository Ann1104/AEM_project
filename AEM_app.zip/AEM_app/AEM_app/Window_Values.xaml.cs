﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AEM_app
{
    /// <summary>
    /// Interaction logic for Window_Values.xaml
    /// </summary>
    public partial class Window_Values : Window
    {
        public DataTable dt;
        public DataColumn dc;

        public Window_Values(string text, List<Point> values)
        {
            InitializeComponent();
            Label_Text.Content = text;
            dt = new DataTable();
            dc = new DataColumn();

            dc = new DataColumn("X");
            dt.Columns.Add(dc);
            dc = new DataColumn("Y");
            dt.Columns.Add(dc);
            
            DataGridTextColumn dgColumn = new DataGridTextColumn
            {
                Header = dt.Columns["X"].ColumnName,
                Binding = new Binding(dt.Columns["X"].ColumnName),
                MinWidth = 123,
                
            };

            dataGrid_Values.Columns.Add(dgColumn);
            dgColumn = new DataGridTextColumn
            {
                Header = dt.Columns["Y"].ColumnName,
                Binding = new Binding(dt.Columns["Y"].ColumnName),
                MinWidth = 123,
            };
            
            dataGrid_Values.Columns.Add(dgColumn);
            for (int i = 0; i < values.Count(); i++)
            {
                dt.Rows.Add(values[i].X, values[i].Y);
            }

            dataGrid_Values.ItemsSource = dt.DefaultView;

        }
    }
}
