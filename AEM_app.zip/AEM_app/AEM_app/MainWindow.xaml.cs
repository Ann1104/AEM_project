﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AEM_app
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Mobius_Click(object sender, RoutedEventArgs e)
        {
            Window_Mobius wm = new Window_Mobius();
            wm.ShowDialog();
        }

        private void Button_Euler_Click(object sender, RoutedEventArgs e)
        {
            Window_Euler we = new Window_Euler();
            we.ShowDialog();
        }

        private void Button_FDH_Click(object sender, RoutedEventArgs e)
        {
            Window_Fermat_Diffie_Hellman wfdh = new Window_Fermat_Diffie_Hellman();
            wfdh.Show();
        }

        private void Button_DH_Click(object sender, RoutedEventArgs e)
        {
            Window_Diffie_Hellman wdh = new Window_Diffie_Hellman();
            wdh.Show();
        }

        private void Button_public_RSA_Click(object sender, RoutedEventArgs e)
        {
            Window_RSA_publicKey wrsapublic = new Window_RSA_publicKey();
            wrsapublic.ShowDialog();
        }

        private void Button_private_RSA_Click(object sender, RoutedEventArgs e)
        {
            Window_RSA_privateKey wrsaprivate = new Window_RSA_privateKey();
            wrsaprivate.ShowDialog();
        }
    }
}
