﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AEM_app
{
    /// <summary>
    /// Interaction logic for Window_Fermat_Diffie_Hellman.xaml
    /// </summary>

    public partial class Window_Fermat_Diffie_Hellman : Window
    {
        public DataTable dt;
        public DataColumn dc;

        public Window_Fermat_Diffie_Hellman()
        {
            InitializeComponent();
        }

        private void Button_Start_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dataGrid_DH.Columns.Clear();
                dataGrid_DH.ItemsSource = null;
                dataGrid_DH.Items.Refresh();

                dt = new DataTable();
                dc = new DataColumn();

                int p = Convert.ToInt32(Tb_value.Text);

                for (int i = 0; i < p; i++)
                {
                    dc = new DataColumn(i.ToString());
                    dt.Columns.Add(dc);
                }

                for (int i = 0; i < p; i++)
                {
                    DataGridTextColumn dgColumn = new DataGridTextColumn
                    {
                        Header = dt.Columns[i].ColumnName,
                        Binding = new Binding(dt.Columns[i].ColumnName),
                        MinWidth = 40,
                    };

                    if (i > 0)
                    {
                        Style columnStyle = new Style(typeof(TextBlock));
                        Trigger backgroundColorTrigger = new Trigger
                        {
                            Property = TextBlock.TextProperty,
                            Value = "1"
                        };
                        backgroundColorTrigger.Setters.Add(
                            new Setter(
                                TextBlock.BackgroundProperty,
                                new SolidColorBrush(Colors.LightGreen)));
                        columnStyle.Triggers.Add(backgroundColorTrigger);
                        dgColumn.ElementStyle = columnStyle;
                    }

                    dataGrid_DH.Columns.Add(dgColumn);
                }

                for (int i = 1; i < p; i++)
                {
                    dt.Rows.Add(i, "");
                }

                for (int i = 1; i < p; i++)
                {

                    for (int j = 1; j < p; j++)
                    {
                        BigInteger potega = System.Numerics.BigInteger.Pow(j, i) % p;

                        if (potega == 1)
                        {
                            dt.Rows[i - 1][j] = potega;
                        }
                        else
                        {
                            dt.Rows[i - 1][j] = potega;
                        }
                    }
                }

                dataGrid_DH.ItemsSource = dt.DefaultView;

                for (int i = 0; i < p; i++)
                {
                    dataGrid_DH.Columns.RemoveAt(p);
                }

            }
            catch (Exception)
            {
                MessageBox.Show("ERROR - sprawdź wprowadzone P !");
            }

        }

    }
}

