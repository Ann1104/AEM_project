﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AEM_app
{
    /// <summary>
    /// Interaction logic for Window_Diffie_Hellman.xaml
    /// </summary>
    public partial class Window_Diffie_Hellman : Window
    {
        public List<Point> listOfPoints;

        public Window_Diffie_Hellman()
        {
            InitializeComponent();
            listOfPoints = new List<Point>();
            Button_Create.IsEnabled = false;
        }

        private void RunDH()
        {
            int p = Convert.ToInt32(valueP.Text);
            int g = Convert.ToInt32(valueG.Text);

            for (int i = 1; i < p; i++)
            {
                System.Numerics.BigInteger bigInt = System.Numerics.BigInteger.Pow(g, i) % p;
                int x = (int)bigInt;
                listOfPoints.Add(new Point(i, x));
            }
        } 

        private void Button_CreateFunction_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                chartE.Series.Clear();
                listOfPoints.Clear();
                RunDH();

                ScatterSeries series = new ScatterSeries
                {
                    DependentValuePath = "Y",
                    IndependentValuePath = "X",
                    ItemsSource = listOfPoints
                };

                chart_X.Maximum = listOfPoints.Max(point => point.Y) + 1;
                chart_X.Minimum = 0;

                chartE.Series.Add(series);

                Window_Values wv = new Window_Values("Diffie Hellman - values", listOfPoints);
                wv.Show();
            }
            catch (Exception)
            {
                MessageBox.Show("ERROR - sprawdź wprowadzone P i G !");
            }

        }

        private void ValueP_KeyDown(object sender, KeyEventArgs e)
        {
            if(valueG.Text != "")
                Button_Create.IsEnabled = true;
        }

        private void ValueG_KeyDown(object sender, KeyEventArgs e)
        {
            if (valueP.Text != "")
                Button_Create.IsEnabled = true;
        }

    }
}
